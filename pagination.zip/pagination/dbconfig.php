<?php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'eod2';
$dbconfig = mysqli_connect($host,$username,$password,$database);
?>
